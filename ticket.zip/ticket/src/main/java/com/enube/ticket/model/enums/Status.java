package com.enube.ticket.model.enums;

public enum Status {
    ACTIVE,
    CANCELED
}
